package com.library;

public class Book {
	private int bookId;
	private String title;
	private String author;
	private int titleSearchCount;
	private int authorSearchCount;

	public Book(int bookId, String title, String author) {
		super();
		this.bookId = bookId;
		this.title = title;
		this.author = author;
		this.titleSearchCount = 0;
		this.authorSearchCount = 0;
	}

	public Book() {
		// TODO Auto-generated constructor stub
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public int getTitleSearchCount() {
		return titleSearchCount;
	}

	public void setTitleSearchCount(int titleSearchCount) {
		this.titleSearchCount = titleSearchCount;
	}

	public int getAuthorSearchCount() {
		return authorSearchCount;
	}

	public void setAuthorSearchCount(int authorSearchCount) {
		this.authorSearchCount = authorSearchCount;
	}

}
