package com.library;

import java.util.ArrayList;
import java.util.List;

public class Library 
{
	private List<Book> books;
	private static int visitorCount;
	private static int totalSearchCount;

	static   //static block
	{
		visitorCount=0;
		totalSearchCount=0;

	}
	public Library() {
		books=new ArrayList();
	}
	public void addBook(Book b)
	{
		if(books.add(b))
			System.out.println("Book added in library...");
			
	}
	public static int getVisitorCount() {
		return visitorCount;
	}
	public List<Book> getBooks() {
		return books;
	}
	public static int getTotalSearchCount() {
		return totalSearchCount;
	}
	public static void setVisitorCount(int visitorCount) {
		Library.visitorCount = visitorCount;
	}
	public static void setTotalSearchCount(int totalSearchCount) {
		Library.totalSearchCount = totalSearchCount;
	}
	
	
}
