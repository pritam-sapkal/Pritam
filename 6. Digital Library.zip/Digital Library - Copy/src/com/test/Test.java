package com.test;

import java.util.Scanner;

import com.library.Book;
import com.library.Library;

public class Test {
	public static void main(String[] args) {
		Library lib = new Library();
		lib.addBook(new Book(101, "Java", "James"));
		lib.addBook(new Book(102, "WCD", "Ram"));
		lib.addBook(new Book(103, "C ", "Dennis"));
		lib.addBook(new Book(104, "C++", "Yash"));
		lib.addBook(new Book(105, "India", "Pritam"));
		lib.addBook(new Book(106, "Dams in India", "Pravin"));
		lib.addBook(new Book(107, "History of India", "Ajit"));
		lib.addBook(new Book(108, "Banking", "Pooja"));
		lib.addBook(new Book(109, "Insurance", "Prachi"));
		lib.addBook(new Book(110, "Geography", "Vibha"));

		int choice = 0;
		Scanner s = new Scanner(System.in);
		do {

			try 
			{
				System.out.println("**********MENU***********");
				System.out.println("1. Search book by title");
				System.out.println("2. Search book by Author name");
				System.out.println("3. Print total number of book searched in a day");
				System.out.println("4. Print the book searched maximum times");
				System.out.println("5. Print the author name searched maximum times");
				System.out.println("6. Exit");
				System.out.println("Enter your choice");
				choice = s.nextInt();
				switch (choice) {
				case 1: {
					boolean flag=false;
					System.out.println("Enter the title you want to search");
					String title = s.next();
					for (Book b : lib.getBooks()) {
						if (title.equalsIgnoreCase(b.getTitle())) {
							System.out.println("Book found as...");
							System.out.println(b.getBookId() + " " + b.getTitle() + " " + b.getAuthor());
							b.setAuthorSearchCount(b.getAuthorSearchCount() + 1);
							b.setTitleSearchCount(b.getTitleSearchCount() + 1);
							Library.setTotalSearchCount(lib.getTotalSearchCount() + 1);
							Library.setVisitorCount(lib.getVisitorCount() + 1);
							flag=true;
							break;
						} 
					}
					if(flag==false)
						System.out.println("No record found..");
					break;
				}
				case 2: {
					boolean flag=false;;
					System.out.println("Enter the author name you want to search");
					String author = s.next();
					for (Book b : lib.getBooks()) {
						if (author.equalsIgnoreCase(b.getAuthor())) {
							System.out.println("Book found with " + author + " as Author are...");
							System.out.println(b.getBookId() + " " + b.getTitle() + " " + b.getAuthor());
							b.setAuthorSearchCount(b.getAuthorSearchCount() + 1);
							b.setTitleSearchCount(b.getTitleSearchCount()+1);
							Library.setTotalSearchCount(lib.getTotalSearchCount() + 1);
							flag=true;
							break;

						} 
					}
					if(flag==false)
						System.out.println("No record found..");

					break;
				}
				case 3: {
					int bookSearchCount = 0;
					for (Book b : lib.getBooks()) {
						bookSearchCount = bookSearchCount + b.getTitleSearchCount();
					}
					System.out.println("total books searched are : " + bookSearchCount);
					break;
				}
				case 4: {
					int maxCount = 0;
					for (Book b : lib.getBooks()) {
						if (b.getTitleSearchCount() > maxCount) {
							maxCount = b.getTitleSearchCount();
						}
					}
					for (Book b : lib.getBooks()) {
						if (b.getTitleSearchCount() == maxCount) {
							System.out.println(b.getTitle() + " was searched maximum times " + maxCount + " times");
						}
					}

					break;
				}
				case 5: {
					int maxCount = 0;
					for (Book b : lib.getBooks()) {
						if (b.getAuthorSearchCount() > maxCount) {
							maxCount = b.getAuthorSearchCount();
						}
					}
					for (Book b : lib.getBooks()) {
						if (b.getAuthorSearchCount() == maxCount) {
							System.out.println(b.getAuthor() + " was searched maximum times " + maxCount + " times");
						}
					}

					break;
				}
				case 6:
					break;

				default:
					System.out.println("Invalid choice");

				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		} while (choice != 6);
	}

}
